/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0A0A0B",
        graphite: "#1C1C1E",
        steel: "#3A3A3D",
        stone: "#86868B",
        mist: "#D4D4D6",
        cloud: "#F0EFEC",
        paper: "#FAFAF8",
        white: "#FFFFFF",
      },
      fontFamily: {
        display: ["General Sans", "Inter", "sans-serif"],
        body: ["Inter", "sans-serif"],
      },
      fontSize: {
        "display-1": ["clamp(3rem, 9vw, 8.5rem)", { lineHeight: "0.95", letterSpacing: "-0.03em" }],
        "display-2": ["clamp(2.25rem, 6vw, 5.5rem)", { lineHeight: "1.0", letterSpacing: "-0.025em" }],
        "display-3": ["clamp(1.75rem, 4vw, 3.25rem)", { lineHeight: "1.05", letterSpacing: "-0.02em" }],
      },
      letterSpacing: {
        tightest: "-0.04em",
        label: "0.08em",
      },
      transitionTimingFunction: {
        signature: "cubic-bezier(0.22, 1, 0.36, 1)",
      },
      maxWidth: {
        content: "1400px",
      },
    },
  },
  plugins: [],
};
