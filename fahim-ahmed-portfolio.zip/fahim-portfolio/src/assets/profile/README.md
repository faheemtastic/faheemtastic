# Add your photo here

Your photo wasn't attached when this project was generated, so each section
currently renders a styled placeholder frame instead of a real image.

Drop **four crops of the same portrait** into this folder using these exact
filenames, and every section will pick them up automatically:

| Filename       | Used in           | Suggested crop                                   |
| -------------- | ----------------- | ------------------------------------------------- |
| `hero.jpg`     | Hero section       | Full-height, cinematic, some headroom above you   |
| `about.jpg`    | About section       | Closer / different angle than the hero crop       |
| `personal.jpg` | "Beyond the code"   | Candid, environmental — used softly, low-key       |
| `contact.jpg`  | Contact section     | Small detail crop (shoulders-up is enough)         |

Guidelines:

- Keep the four crops visually distinct — don't reuse the same framing twice.
- Use natural, professional lighting. Avoid heavy filters or AI touch-ups —
  the brief asks for the real you, not a generated likeness.
- Export at at least 2000px on the long edge so the responsive `<img>` set in
  `src/components/Portrait.tsx` has room to downscale cleanly.
- JPG or WebP both work. If you use different extensions, update the
  `PROFILE_IMAGES` map in `src/components/Portrait.tsx`.
