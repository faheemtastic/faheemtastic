# Add project images here

Drop screenshots or hero images for each project here and point `image` in
`src/data/projects.ts` at them, e.g. `/src/assets/projects/matrix-library.jpg`.

Until you do, `src/components/Projects.tsx` renders a quiet placeholder frame
for any project image that fails to load, so the layout never breaks.
