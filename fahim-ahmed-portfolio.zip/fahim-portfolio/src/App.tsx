import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { Intro } from "./components/Intro";
import { About } from "./components/About";
import { Projects } from "./components/Projects";
import { Skills } from "./components/Skills";
import { Education } from "./components/Education";
import { Personal } from "./components/Personal";
import { Statement } from "./components/Statement";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-ink text-white">
      <Navbar />
      <main>
        <Hero />
        <Intro />
        <About />
        <Projects />
        <Skills />
        <Education />
        <Personal />
        <Statement />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
