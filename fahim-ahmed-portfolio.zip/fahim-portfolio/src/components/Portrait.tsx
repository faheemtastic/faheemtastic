import { useState } from "react";

type PortraitVariant = "hero" | "about" | "personal" | "contact";

const PROFILE_IMAGES: Record<PortraitVariant, string> = {
  hero: "/src/assets/profile/hero.jpg",
  about: "/src/assets/profile/about.jpg",
  personal: "/src/assets/profile/personal.jpg",
  contact: "/src/assets/profile/contact.jpg",
};

const PLACEHOLDER_LABEL: Record<PortraitVariant, string> = {
  hero: "hero.jpg",
  about: "about.jpg",
  personal: "personal.jpg",
  contact: "contact.jpg",
};

interface PortraitProps {
  variant: PortraitVariant;
  className?: string;
  imgClassName?: string;
  alt?: string;
}

/**
 * Renders one of the four portrait crops described in
 * src/assets/profile/README.md. If the file hasn't been added yet, falls
 * back to a quiet, on-brand placeholder frame instead of a broken image.
 */
export function Portrait({ variant, className = "", imgClassName = "", alt }: PortraitProps) {
  const [failed, setFailed] = useState(false);
  const src = PROFILE_IMAGES[variant];

  if (failed) {
    return (
      <div
        className={`relative flex items-center justify-center overflow-hidden bg-gradient-to-br from-graphite via-ink to-black ${className}`}
        role="img"
        aria-label={alt ?? "Portrait placeholder"}
      >
        <div className="absolute inset-0 opacity-40 [background-image:radial-gradient(circle_at_30%_20%,#3a3a3d_0%,transparent_45%)]" />
        <div className="relative flex flex-col items-center gap-3 px-6 text-center">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" className="text-stone" aria-hidden="true">
            <circle cx="12" cy="8" r="3.5" stroke="currentColor" strokeWidth="1.4" />
            <path d="M4.5 19c1.6-3.4 4.4-5 7.5-5s5.9 1.6 7.5 5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
          </svg>
          <p className="text-xs tracking-label text-stone">
            Add <span className="text-mist">{PLACEHOLDER_LABEL[variant]}</span>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`overflow-hidden ${className}`}>
      <img
        src={src}
        alt={alt ?? "Fahim Ahmed"}
        loading={variant === "hero" ? "eager" : "lazy"}
        decoding="async"
        onError={() => setFailed(true)}
        className={`h-full w-full object-cover ${imgClassName}`}
      />
    </div>
  );
}
