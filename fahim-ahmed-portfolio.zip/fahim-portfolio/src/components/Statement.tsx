import { motion } from "framer-motion";

const LINES = ["Curious by nature.", "Driven by technology.", "Always building."];

export function Statement() {
  return (
    <section className="section-pad content-max py-32 md:py-48">
      <div className="flex flex-col gap-1 md:gap-2">
        {LINES.map((line, index) => (
          <motion.p
            key={line}
            initial={{ opacity: 0.15, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.7 }}
            transition={{ duration: 0.8, delay: index * 0.15, ease: [0.22, 1, 0.36, 1] }}
            className="font-display text-display-2 text-balance"
          >
            {line}
          </motion.p>
        ))}
      </div>
    </section>
  );
}
