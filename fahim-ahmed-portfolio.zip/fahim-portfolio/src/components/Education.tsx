import { motion } from "framer-motion";
import { educationTimeline } from "../data/education";

export function Education() {
  return (
    <section id="education" className="section-pad content-max py-28 md:py-40">
      <motion.h2
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="font-display text-display-2 text-balance mb-16 md:mb-24"
      >
        Always learning.
      </motion.h2>

      <div className="max-w-3xl divide-y divide-white/10 border-t border-white/10">
        {educationTimeline.map((entry, index) => (
          <motion.div
            key={`${entry.institution}-${index}`}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.7, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="flex flex-col gap-2 py-8 md:flex-row md:items-baseline md:justify-between md:gap-8"
          >
            <div>
              <h3 className="font-display text-xl md:text-2xl">{entry.institution}</h3>
              <p className="mt-1 text-mist">{entry.program}</p>
              {entry.note && <p className="mt-2 max-w-md text-sm text-stone">{entry.note}</p>}
            </div>
            <span className="whitespace-nowrap text-sm text-stone">{entry.period}</span>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
