import { motion } from "framer-motion";
import { skillCategories } from "../data/skills";

export function Skills() {
  return (
    <section id="skills" className="section-pad content-max py-28 md:py-40">
      <motion.h2
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="font-display text-display-2 text-balance mb-20 md:mb-28"
      >
        Tools I work with.
      </motion.h2>

      <div className="grid grid-cols-1 gap-x-8 gap-y-16 md:grid-cols-3">
        {skillCategories.map((category, categoryIndex) => (
          <div key={category.label}>
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.6 }}
              transition={{ duration: 0.5, delay: categoryIndex * 0.08 }}
              className="eyebrow mb-6 border-b border-white/10 pb-4"
            >
              {category.label}
            </motion.p>

            <ul className="space-y-1">
              {category.skills.map((skill, skillIndex) => (
                <motion.li
                  key={skill}
                  initial={{ opacity: 0, x: -12 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, amount: 0.6 }}
                  transition={{
                    duration: 0.5,
                    delay: categoryIndex * 0.08 + skillIndex * 0.05,
                    ease: [0.22, 1, 0.36, 1],
                  }}
                  className="group cursor-default py-2.5"
                >
                  <span className="font-display text-xl text-mist transition-colors duration-300 group-hover:text-white md:text-2xl">
                    {skill}
                  </span>
                </motion.li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}
