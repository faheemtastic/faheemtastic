import { motion } from "framer-motion";

export function Intro() {
  return (
    <section className="section-pad content-max py-28 md:py-40">
      <motion.h2
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="font-display text-display-2 text-balance max-w-4xl"
      >
        I turn ideas into experiences.
      </motion.h2>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.7, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
        className="mt-8 max-w-xl text-lg text-mist md:text-xl"
      >
        Fahim Ahmed is a computer science student and developer focused on building useful,
        intuitive, and beautifully designed digital experiences.
      </motion.p>
    </section>
  );
}
