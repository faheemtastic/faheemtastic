import { motion } from "framer-motion";
import { Portrait } from "./Portrait";

/**
 * EDITABLE — swap these for your real interests. Keep it to a handful;
 * this section works best when it stays quiet and specific.
 */
const INTERESTS = [
  "REPLACE — an interest or hobby",
  "REPLACE — another one",
  "REPLACE — a third, optional",
];

export function Personal() {
  return (
    <section className="relative overflow-hidden py-28 md:py-40">
      <div className="absolute inset-0">
        <Portrait variant="personal" className="h-full w-full" imgClassName="grayscale opacity-30" alt="" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/85 to-ink/60" />
      </div>

      <div className="relative section-pad content-max">
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.6 }}
          transition={{ duration: 0.6 }}
          className="eyebrow mb-4"
        >
          Off screen
        </motion.p>

        <motion.h2
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.8, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          className="font-display text-display-2 text-balance max-w-2xl"
        >
          Beyond the code.
        </motion.h2>

        <motion.ul
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          className="mt-10 flex max-w-lg flex-col gap-3 text-lg text-mist"
        >
          {INTERESTS.map((interest) => (
            <li key={interest}>{interest}</li>
          ))}
        </motion.ul>
      </div>
    </section>
  );
}
