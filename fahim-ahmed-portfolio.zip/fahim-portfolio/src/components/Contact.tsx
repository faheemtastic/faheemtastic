import { useState, FormEvent } from "react";
import { motion } from "framer-motion";
import { Portrait } from "./Portrait";
import { socialLinks } from "../data/socialLinks";

interface FormState {
  name: string;
  email: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  message?: string;
}

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate(values: FormState): FormErrors {
  const errors: FormErrors = {};
  if (!values.name.trim()) errors.name = "Enter your name.";
  if (!values.email.trim()) {
    errors.email = "Enter your email.";
  } else if (!EMAIL_PATTERN.test(values.email)) {
    errors.email = "Enter a valid email address.";
  }
  if (!values.message.trim()) errors.message = "Write a short message.";
  return errors;
}

export function Contact() {
  const [values, setValues] = useState<FormState>({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState<FormErrors>({});
  const [status, setStatus] = useState<"idle" | "submitting" | "sent">("idle");

  const handleChange = (field: keyof FormState) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setValues((prev) => ({ ...prev, [field]: e.target.value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const nextErrors = validate(values);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    // NOTE: this is a front-end placeholder. Wire this up to a real
    // endpoint, form service (e.g. Formspree), or email API before launch.
    setStatus("submitting");
    setTimeout(() => {
      setStatus("sent");
    }, 900);
  };

  return (
    <section id="contact" className="section-pad content-max py-28 md:py-40">
      <div className="grid grid-cols-1 gap-16 md:grid-cols-12 md:gap-8">
        <div className="md:col-span-6">
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 0.6 }}
            className="eyebrow mb-4"
          >
            Contact
          </motion.p>

          <motion.h2
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.8, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="font-display text-display-2 text-balance"
          >
            Let's build something.
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-6 max-w-sm text-lg text-mist"
          >
            Have an idea, project, or opportunity? I'd love to hear from you.
          </motion.p>

          <div className="mt-10 flex items-center gap-6">
            <Portrait
              variant="contact"
              className="h-16 w-16 shrink-0 rounded-full"
              imgClassName="grayscale-[20%]"
              alt="Fahim Ahmed"
            />
            <ul className="flex flex-wrap gap-x-6 gap-y-2">
              {socialLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.url}
                    target={link.url.startsWith("mailto:") ? undefined : "_blank"}
                    rel="noreferrer"
                    className="text-sm text-mist underline-offset-4 transition-colors duration-300 hover:text-white hover:underline"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <motion.form
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          onSubmit={handleSubmit}
          noValidate
          className="md:col-span-6"
        >
          <div className="space-y-6">
            <div>
              <label htmlFor="name" className="mb-2 block text-xs tracking-label text-stone">
                Name
              </label>
              <input
                id="name"
                type="text"
                value={values.name}
                onChange={handleChange("name")}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? "name-error" : undefined}
                className="w-full border-b border-white/20 bg-transparent py-3 text-base outline-none transition-colors duration-300 focus:border-white"
              />
              {errors.name && (
                <p id="name-error" className="mt-2 text-xs text-mist">
                  {errors.name}
                </p>
              )}
            </div>

            <div>
              <label htmlFor="email" className="mb-2 block text-xs tracking-label text-stone">
                Email
              </label>
              <input
                id="email"
                type="email"
                value={values.email}
                onChange={handleChange("email")}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? "email-error" : undefined}
                className="w-full border-b border-white/20 bg-transparent py-3 text-base outline-none transition-colors duration-300 focus:border-white"
              />
              {errors.email && (
                <p id="email-error" className="mt-2 text-xs text-mist">
                  {errors.email}
                </p>
              )}
            </div>

            <div>
              <label htmlFor="message" className="mb-2 block text-xs tracking-label text-stone">
                Message
              </label>
              <textarea
                id="message"
                rows={4}
                value={values.message}
                onChange={handleChange("message")}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? "message-error" : undefined}
                className="w-full resize-none border-b border-white/20 bg-transparent py-3 text-base outline-none transition-colors duration-300 focus:border-white"
              />
              {errors.message && (
                <p id="message-error" className="mt-2 text-xs text-mist">
                  {errors.message}
                </p>
              )}
            </div>
          </div>

          <button
            type="submit"
            disabled={status === "submitting"}
            className="mt-10 w-full rounded-full bg-white py-4 text-sm font-medium text-ink transition-transform duration-300 hover:scale-[1.01] disabled:opacity-60 md:w-auto md:px-10"
          >
            {status === "sent" ? "Message sent" : status === "submitting" ? "Sending…" : "Send message"}
          </button>

          {status === "sent" && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-4 text-sm text-stone"
            >
              Thanks for reaching out — I'll get back to you soon.
            </motion.p>
          )}
        </motion.form>
      </div>
    </section>
  );
}
