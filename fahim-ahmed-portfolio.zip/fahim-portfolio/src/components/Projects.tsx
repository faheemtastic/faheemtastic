import { useState } from "react";
import { motion } from "framer-motion";
import { projects } from "../data/projects";

function ProjectImage({ src, name }: { src: string; name: string }) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div className="flex aspect-[16/10] w-full items-center justify-center bg-graphite">
        <p className="eyebrow">Add an image for {name}</p>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={`${name} preview`}
      loading="lazy"
      onError={() => setFailed(true)}
      className="aspect-[16/10] w-full object-cover"
    />
  );
}

export function Projects() {
  return (
    <section id="projects" className="section-pad content-max py-28 md:py-40">
      <motion.h2
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="font-display text-display-2 text-balance mb-20 md:mb-28"
      >
        Things I've built.
      </motion.h2>

      <div className="flex flex-col gap-28 md:gap-36">
        {projects.map((project, index) => {
          const reversed = index % 2 === 1;
          return (
            <motion.article
              key={project.id}
              initial={{ opacity: 0, y: 48 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
              className="grid grid-cols-1 items-center gap-10 md:grid-cols-12 md:gap-8"
            >
              <div className={`md:col-span-7 ${reversed ? "md:order-2" : ""}`}>
                <ProjectImage src={project.image} name={project.name} />
              </div>

              <div className={`md:col-span-5 ${reversed ? "md:order-1" : ""}`}>
                <p className="eyebrow mb-3">{project.category}</p>
                <h3 className="font-display text-2xl md:text-3xl tracking-tight">{project.name}</h3>
                <p className="mt-4 max-w-md text-base leading-relaxed text-mist">{project.description}</p>

                <dl className="mt-6 space-y-2">
                  <div className="flex gap-2 text-sm">
                    <dt className="text-stone">Role</dt>
                    <dd className="text-mist">{project.role}</dd>
                  </div>
                  <div className="flex gap-2 text-sm">
                    <dt className="text-stone">Built with</dt>
                    <dd className="text-mist">{project.technologies.join(", ")}</dd>
                  </div>
                </dl>

                <div className="mt-8 flex flex-wrap gap-3">
                  {project.githubUrl && (
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="rounded-full border border-white/25 px-5 py-2.5 text-sm transition-colors duration-300 hover:border-white/60"
                    >
                      GitHub
                    </a>
                  )}
                  {project.demoUrl && (
                    <a
                      href={project.demoUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="rounded-full bg-white px-5 py-2.5 text-sm font-medium text-ink transition-transform duration-300 hover:scale-[1.03]"
                    >
                      Live demo
                    </a>
                  )}
                  {project.learnMoreUrl && (
                    <a
                      href={project.learnMoreUrl}
                      className="px-2 py-2.5 text-sm text-stone transition-colors duration-300 hover:text-white"
                    >
                      Learn more
                    </a>
                  )}
                </div>
              </div>
            </motion.article>
          );
        })}
      </div>
    </section>
  );
}
