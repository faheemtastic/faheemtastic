import { motion } from "framer-motion";
import { Portrait } from "./Portrait";

const FOCUS_AREAS = [
  "Computer Science",
  "Software Development",
  "Problem Solving",
  "Technology",
  "Design",
  "Continuous Learning",
];

export function About() {
  return (
    <section id="about" className="section-pad content-max py-28 md:py-40">
      <div className="grid grid-cols-1 gap-14 md:grid-cols-12 md:gap-8">
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="md:col-span-5"
        >
          <Portrait
            variant="about"
            className="aspect-[4/5] w-full rounded-sm"
            imgClassName="grayscale-[10%]"
            alt="Fahim Ahmed, portrait"
          />
        </motion.div>

        <div className="md:col-span-7 md:pl-6">
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="eyebrow mb-4"
          >
            About
          </motion.p>

          <motion.h2
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.8, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="font-display text-display-3 text-balance"
          >
            A little about me.
          </motion.h2>

          {/*
            EDITABLE BIOGRAPHY — replace this paragraph with your own story.
            No employers, achievements, or credentials are invented here;
            write in your own voice.
          */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.7, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="mt-6 max-w-xl text-base leading-relaxed text-mist md:text-lg"
          >
            REPLACE ME — a few sentences about who you are, what got you into computer science,
            and what kind of problems you like to work on. Keep it in your own words; this is the
            most personal section of the site.
          </motion.p>

          <motion.ul
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-10 flex flex-wrap gap-x-8 gap-y-3"
          >
            {FOCUS_AREAS.map((area) => (
              <li key={area} className="text-sm text-stone">
                {area}
              </li>
            ))}
          </motion.ul>
        </div>
      </div>
    </section>
  );
}
