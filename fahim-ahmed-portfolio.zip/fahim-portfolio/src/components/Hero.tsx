import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Portrait } from "./Portrait";
import { useReducedMotion } from "../hooks/useReducedMotion";

export function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const reducedMotion = useReducedMotion();

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end start"],
  });

  const imageY = useTransform(scrollYProgress, [0, 1], reducedMotion ? [0, 0] : [0, 120]);
  const imageScale = useTransform(scrollYProgress, [0, 1], reducedMotion ? [1, 1] : [1, 1.08]);
  const overlayOpacity = useTransform(scrollYProgress, [0, 1], [0.35, 0.75]);
  const contentOpacity = useTransform(scrollYProgress, [0, 0.6], [1, 0]);

  return (
    <section id="home" ref={sectionRef} className="relative h-[100svh] w-full overflow-hidden bg-ink">
      {/* Portrait, full-bleed */}
      <motion.div style={{ y: imageY, scale: imageScale }} className="absolute inset-0">
        <motion.div
          initial={{ clipPath: "inset(100% 0% 0% 0%)" }}
          animate={{ clipPath: "inset(0% 0% 0% 0%)" }}
          transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
          className="h-full w-full"
        >
          <Portrait
            variant="hero"
            className="h-full w-full"
            imgClassName="[object-position:center_20%] grayscale-[15%]"
            alt="Fahim Ahmed"
          />
        </motion.div>
      </motion.div>

      {/* Gradient lighting */}
      <motion.div
        style={{ opacity: overlayOpacity }}
        className="absolute inset-0 bg-gradient-to-t from-ink via-ink/20 to-transparent"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-ink/70 via-transparent to-ink/30" />

      {/* Content */}
      <motion.div
        style={{ opacity: contentOpacity }}
        className="relative z-10 flex h-full flex-col justify-end section-pad content-max pb-16 md:pb-24"
      >
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="eyebrow mb-5"
        >
          Computer Science Student · Developer · Creator
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="font-display text-display-1 text-balance"
        >
          Hello, I'm Fahim.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.15, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="mt-6 max-w-lg text-lg text-mist"
        >
          I build digital experiences where technology meets thoughtful design.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.3, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="mt-10 flex flex-wrap items-center gap-4"
        >
          <a
            href="#projects"
            onClick={(e) => {
              e.preventDefault();
              document.querySelector("#projects")?.scrollIntoView({ behavior: "smooth" });
            }}
            className="rounded-full bg-white px-7 py-3.5 text-sm font-medium text-ink transition-transform duration-300 hover:scale-[1.03]"
          >
            Explore my work
          </a>
          <a
            href="#about"
            onClick={(e) => {
              e.preventDefault();
              document.querySelector("#about")?.scrollIntoView({ behavior: "smooth" });
            }}
            className="rounded-full border border-white/30 px-7 py-3.5 text-sm font-medium text-white transition-colors duration-300 hover:border-white/70"
          >
            About me
          </a>
        </motion.div>
      </motion.div>

      {/* Scroll cue */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6, duration: 0.8 }}
        className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 md:block"
      >
        <div className="h-9 w-px overflow-hidden bg-white/20">
          <motion.div
            animate={reducedMotion ? undefined : { y: ["-100%", "100%"] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
            className="h-full w-full bg-white"
          />
        </div>
      </motion.div>
    </section>
  );
}
