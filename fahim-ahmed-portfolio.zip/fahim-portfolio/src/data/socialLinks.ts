export interface SocialLink {
  label: string;
  url: string;
}

/**
 * EDITABLE — replace with your real profile URLs and email.
 * Placeholder values are marked with "#" or example.com.
 */
export const socialLinks: SocialLink[] = [
  { label: "Email", url: "mailto:hello@example.com" },
  { label: "GitHub", url: "https://github.com/your-username" },
  { label: "LinkedIn", url: "https://linkedin.com/in/your-username" },
  { label: "Instagram", url: "https://instagram.com/your-username" },
];
