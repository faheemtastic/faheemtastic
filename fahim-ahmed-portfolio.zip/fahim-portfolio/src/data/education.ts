export interface EducationEntry {
  institution: string;
  program: string;
  /** Free text, e.g. "2023 — Present". Replace with real dates. */
  period: string;
  note?: string;
}

/**
 * EDITABLE — dates, program name, and notes are placeholders. No GPA,
 * honors, or achievements are invented here; add them yourself if applicable.
 */
export const educationTimeline: EducationEntry[] = [
  {
    institution: "Los Angeles City College",
    program: "Computer Science",
    period: "REPLACE WITH YOUR DATES",
    note: "REPLACE — optional one-line note about focus areas or coursework.",
  },
];
