export interface SkillCategory {
  label: string;
  skills: string[];
}

/**
 * EDITABLE — add, remove, or reorder freely. Order here is render order.
 */
export const skillCategories: SkillCategory[] = [
  {
    label: "Languages",
    skills: ["C++", "Python", "JavaScript", "TypeScript"],
  },
  {
    label: "Web",
    skills: ["HTML", "CSS", "React", "Tailwind CSS"],
  },
  {
    label: "Tools",
    skills: ["Git", "GitHub", "VS Code"],
  },
];
