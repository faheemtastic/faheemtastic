export interface Project {
  id: string;
  /** Short category label — not a step number, since projects aren't a sequence. */
  category: string;
  name: string;
  description: string;
  technologies: string[];
  role: string;
  image: string;
  githubUrl?: string;
  demoUrl?: string;
  learnMoreUrl?: string;
}

/**
 * PLACEHOLDER DATA — replace with your real projects.
 * Each project renders as a full editorial section on the Projects page.
 * `image` expects a path in /src/assets — drop your own project screenshots there.
 */
export const projects: Project[] = [
  {
    id: "matrix-library",
    category: "Systems",
    name: "Matrix Library",
    description:
      "REPLACE ME — a short, honest description of what this project does, why you built it, and the problem it solves. One or two sentences is enough.",
    technologies: ["C++"],
    role: "Sole developer",
    image: "/src/assets/projects/placeholder-01.jpg",
    githubUrl: "#",
    demoUrl: undefined,
    learnMoreUrl: "#",
  },
  {
    id: "sorting-benchmark",
    category: "Tooling",
    name: "Sorting Algorithm Benchmark",
    description:
      "REPLACE ME — describe the benchmark: which algorithms, what you measured, and what you learned from the results.",
    technologies: ["Python"],
    role: "Sole developer",
    image: "/src/assets/projects/placeholder-02.jpg",
    githubUrl: "#",
    demoUrl: undefined,
    learnMoreUrl: "#",
  },
  {
    id: "personal-project",
    category: "Web",
    name: "Personal Project",
    description:
      "REPLACE ME — this slot is reserved for your next build. Swap in the name, description, stack, and links once it's ready to show.",
    technologies: ["React", "TypeScript"],
    role: "Sole developer",
    image: "/src/assets/projects/placeholder-03.jpg",
    githubUrl: "#",
    demoUrl: "#",
    learnMoreUrl: "#",
  },
];
