# Fahim Ahmed — Personal Portfolio

A premium, Apple-inspired personal site built with React, TypeScript, Tailwind CSS,
and Framer Motion.

## Run it locally

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually `http://localhost:5173`).

To build for production:

```bash
npm run build
npm run preview
```

## Add your photo

No photo was available when this project was generated, so every portrait
slot currently shows a quiet placeholder frame. See
`src/assets/profile/README.md` for exactly which four filenames to add and
where each one is used (hero, about, personal, contact).

## Edit your content

Everything you're likely to want to change lives in `src/data/`:

- `projects.ts` — your real projects, images, links, and tech stack
- `skills.ts` — languages, frameworks, and tools, grouped by category
- `education.ts` — your school, program, and dates
- `socialLinks.ts` — your real email, GitHub, LinkedIn, Instagram URLs

Two more spots to personalize by hand:

- `src/components/About.tsx` — the biography paragraph (marked `REPLACE ME`)
- `src/components/Personal.tsx` — the "Beyond the code" interests list

## Structure

```
src/
  components/   One component per section (Navbar, Hero, About, Projects...)
  data/         Editable content: projects, skills, education, social links
  hooks/        useReducedMotion, useScrolled
  assets/       Your photo and project images go here
```

## Notes

- The contact form validates client-side but doesn't send anywhere yet —
  wire `handleSubmit` in `src/components/Contact.tsx` to a real endpoint
  (e.g. Formspree, a serverless function, or your own API) before launch.
- Motion respects `prefers-reduced-motion` throughout.
- The palette, type scale, and spacing tokens live in `tailwind.config.js`.
